package com.example.lookingrestaurants;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;


public class Seleccion extends AppCompatActivity {
ImageButton cuchara,bongo,oishii,vilabrasil,almounia;
TextView cu,bo,oi,vi,almu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion);

         //para los botones
       cuchara=findViewById(R.id.butonCuchara);
        bongo=findViewById(R.id.butonbongo);
        oishii=findViewById(R.id.butonoishii);
        vilabrasil=findViewById(R.id.butonvilabrasil);
        almounia=findViewById(R.id.butonAlmounia);

        //para los textview
        cu=findViewById(R.id.cu);
        bo=findViewById(R.id.bo);
        oi=findViewById(R.id.oi);
        vi=findViewById(R.id.vi);
        almu=findViewById(R.id.al);

        //recogemos el id del usuario
        Intent intent = getIntent();
        final int user_id = intent.getIntExtra("user_id",1 );

        //-----------------------------------------------------------------------------------------

       //para el boton cuchara
        cuchara.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            //usaremos el nombre del restaurante para que la base de datos sepa que datos nos tiene que devolver
                                            final String Nombre = cu.getText().toString();
                                            Response.Listener<String> responseListener = new Response.Listener<String>() {
                                                @Override
                                                public void onResponse(String response) {
                                                    try {
                                                        JSONObject jsonResponse = new JSONObject(response);
                                                        boolean success = jsonResponse.getBoolean("success");
                                                        if (success){
                                                            //recogemos de la base de datos el id, descripcion y nombre del restaurante mediante la clase Restaurantes :
                                                            final int restaurante_id = jsonResponse.getInt("restaurante_id");
                                                            final String Descripcion = jsonResponse.getString("Descripcion");
                                                            final String Nombre = jsonResponse.getString("Nombre");

                                                            //iremos al contenido del restaurante seleccionado
                                                            Intent intent = new Intent(Seleccion.this, Cuchara.class);

                                                            //nos llevaremos los comentarios , el id del usuario, el id del restaurante, la descripcion y nombre del restaurante
                                                            intent.putStringArrayListExtra("comentarios",  new ArrayList<String>());
                                                            if (jsonResponse.getBoolean("comentario")){
                                                                if (jsonResponse.getBoolean("comentario") ==true){
                                                                    ArrayList<String> comentarios = new ArrayList<>();
                                                                    JSONArray jArray = (JSONArray) jsonResponse.get("comentarios");
                                                                    if (jArray != null) {
                                                                        for (int i=0;i<jArray.length();i++){
                                                                            comentarios.add(jArray.getString(i));
                                                                        }
                                                                    }
                                                                    intent.putStringArrayListExtra("comentarios",  comentarios);
                                                                }
                                                            }
                                                            intent.putExtra("user_id", user_id);
                                                            intent.putExtra("restaurant",restaurante_id );
                                                            intent.putExtra("Descripcion",Descripcion);
                                                            intent.putExtra("Nombre",Nombre);
                                                            Seleccion.this.startActivity(intent);
                                                        }


                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                            };
                                            Restaurantes restaurantes = new Restaurantes(Nombre,responseListener);
                                            RequestQueue queue = Volley.newRequestQueue(Seleccion.this);
                                            queue.add(restaurantes);
                                        }


                                    }
        );


        //------------------------------------------------------------------------------------

        //para el boton bongo
        bongo.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           //usaremos el nombre del restaurante para que la base de datos sepa que datos nos tiene que devolver
                                           final String Nombre = bo.getText().toString();
                                           Response.Listener<String> responseListener = new Response.Listener<String>() {
                                               @Override
                                               public void onResponse(String response) {
                                                   try {
                                                       JSONObject jsonResponse = new JSONObject(response);
                                                       boolean success = jsonResponse.getBoolean("success");
                                                       if (success){
                                                           //recogemos de la base de datos el id, descripcion y nombre del restaurante mediante la clase Restaurantes :
                                                           final int restaurante_id = jsonResponse.getInt("restaurante_id");
                                                           final String Descripcion = jsonResponse.getString("Descripcion");
                                                           final String Nombre = jsonResponse.getString("Nombre");

                                                           //iremos al contenido del restaurante seleccionado
                                                           Intent intent = new Intent(Seleccion.this, ELBONGO.class);

                                                           //nos llevaremos los comentarios , el id del usuario, el id del restaurante, la descripcion y nombre del restaurante
                                                           intent.putStringArrayListExtra("comentarios",  new ArrayList<String>());
                                                           if (jsonResponse.getBoolean("comentario")){
                                                               if (jsonResponse.getBoolean("comentario") ==true){
                                                                   ArrayList<String> comentarios = new ArrayList<>();
                                                                   JSONArray jArray = (JSONArray) jsonResponse.get("comentarios");
                                                                   if (jArray != null) {
                                                                       for (int i=0;i<jArray.length();i++){
                                                                           comentarios.add(jArray.getString(i));
                                                                       }
                                                                   }
                                                                   intent.putStringArrayListExtra("comentarios",  comentarios);
                                                               }
                                                           }
                                                           intent.putExtra("user_id", user_id);
                                                           intent.putExtra("restaurant",restaurante_id );
                                                           intent.putExtra("Descripcion",Descripcion);
                                                           intent.putExtra("Nombre",Nombre);
                                                           Seleccion.this.startActivity(intent);
                                                       }


                                                   } catch (JSONException e) {
                                                       e.printStackTrace();
                                                   }
                                               }
                                           };
                                           Restaurantes restaurantes = new Restaurantes(Nombre,responseListener);
                                           RequestQueue queue = Volley.newRequestQueue(Seleccion.this);
                                           queue.add(restaurantes);
                                       }


                                   }
        );


        //------------------------------------------------------------------------------------

        //para el boton oishii
        oishii.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         //usaremos el nombre del restaurante para que la base de datos sepa que datos nos tiene que devolver
                                         final String Nombre = oi.getText().toString();
                                         Response.Listener<String> responseListener = new Response.Listener<String>() {
                                             @Override
                                             public void onResponse(String response) {
                                                 try {
                                                     JSONObject jsonResponse = new JSONObject(response);
                                                     boolean success = jsonResponse.getBoolean("success");
                                                     if (success){
                                                         //recogemos de la base de datos el id, descripcion y nombre del restaurante mediante la clase Restaurantes :
                                                         final int restaurante_id = jsonResponse.getInt("restaurante_id");
                                                         final String Descripcion = jsonResponse.getString("Descripcion");
                                                         final String Nombre = jsonResponse.getString("Nombre");

                                                         //iremos al contenido del restaurante seleccionado
                                                         Intent intent = new Intent(Seleccion.this, OISHII.class);

                                                         //nos llevaremos los comentarios , el id del usuario, el id del restaurante, la descripcion y nombre del restaurante
                                                         intent.putStringArrayListExtra("comentarios",  new ArrayList<String>());
                                                         if (jsonResponse.getBoolean("comentario")){
                                                             if (jsonResponse.getBoolean("comentario") ==true){
                                                                 ArrayList<String> comentarios = new ArrayList<>();
                                                                 JSONArray jArray = (JSONArray) jsonResponse.get("comentarios");
                                                                 if (jArray != null) {
                                                                     for (int i=0;i<jArray.length();i++){
                                                                         comentarios.add(jArray.getString(i));
                                                                     }
                                                                 }
                                                                 intent.putStringArrayListExtra("comentarios",  comentarios);
                                                             }
                                                         }
                                                         intent.putExtra("user_id", user_id);
                                                         intent.putExtra("restaurant",restaurante_id );
                                                         intent.putExtra("Descripcion",Descripcion);
                                                         intent.putExtra("Nombre",Nombre);
                                                         Seleccion.this.startActivity(intent);
                                                     }


                                                 } catch (JSONException e) {
                                                     e.printStackTrace();
                                                 }
                                             }
                                         };
                                         Restaurantes restaurantes = new Restaurantes(Nombre,responseListener);
                                         RequestQueue queue = Volley.newRequestQueue(Seleccion.this);
                                         queue.add(restaurantes);
                                     }


                                 }
        );



        //------------------------------------------------------------------------------------

        //para el boton vilabrasil
        vilabrasil.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         //usaremos el nombre del restaurante para que la base de datos sepa que datos nos tiene que devolver
                                         final String Nombre = vi.getText().toString();
                                         Response.Listener<String> responseListener = new Response.Listener<String>() {
                                             @Override
                                             public void onResponse(String response) {
                                                 try {
                                                     JSONObject jsonResponse = new JSONObject(response);
                                                     boolean success = jsonResponse.getBoolean("success");
                                                     if (success){
                                                         //recogemos de la base de datos el id, descripcion y nombre del restaurante mediante la clase Restaurantes :
                                                         final int restaurante_id = jsonResponse.getInt("restaurante_id");
                                                         final String Descripcion = jsonResponse.getString("Descripcion");
                                                         final String Nombre = jsonResponse.getString("Nombre");

                                                         //iremos al contenido del restaurante seleccionado
                                                         Intent intent = new Intent(Seleccion.this, vilabrasil.class);

                                                         //nos llevaremos los comentarios , el id del usuario, el id del restaurante, la descripcion y nombre del restaurante
                                                         intent.putStringArrayListExtra("comentarios",  new ArrayList<String>());
                                                         if (jsonResponse.getBoolean("comentario")){
                                                             if (jsonResponse.getBoolean("comentario") ==true){
                                                                 ArrayList<String> comentarios = new ArrayList<>();
                                                                 JSONArray jArray = (JSONArray) jsonResponse.get("comentarios");
                                                                 if (jArray != null) {
                                                                     for (int i=0;i<jArray.length();i++){
                                                                         comentarios.add(jArray.getString(i));
                                                                     }
                                                                 }
                                                                 intent.putStringArrayListExtra("comentarios",  comentarios);
                                                             }
                                                         }
                                                         intent.putExtra("user_id", user_id);
                                                         intent.putExtra("restaurant",restaurante_id );
                                                         intent.putExtra("Descripcion",Descripcion);
                                                         intent.putExtra("Nombre",Nombre);
                                                         Seleccion.this.startActivity(intent);
                                                     }


                                                 } catch (JSONException e) {
                                                     e.printStackTrace();
                                                 }
                                             }
                                         };
                                         Restaurantes restaurantes = new Restaurantes(Nombre,responseListener);
                                         RequestQueue queue = Volley.newRequestQueue(Seleccion.this);
                                         queue.add(restaurantes);
                                     }


                                 }
        );






        //--------------------------------------------------------------------------------------------------------------


        //para el boton almounia
        almounia.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         //usaremos el nombre del restaurante para que la base de datos sepa que datos nos tiene que devolver
                                         final String Nombre = almu.getText().toString();
                                         Response.Listener<String> responseListener = new Response.Listener<String>() {
                                             @Override
                                             public void onResponse(String response) {
                                                 try {
                                                     JSONObject jsonResponse = new JSONObject(response);
                                                     boolean success = jsonResponse.getBoolean("success");
                                                     if (success){
                                                         //recogemos de la base de datos el id, descripcion y nombre del restaurante mediante la clase Restaurantes :
                                                         final int restaurante_id = jsonResponse.getInt("restaurante_id");
                                                         final String Descripcion = jsonResponse.getString("Descripcion");
                                                         final String Nombre = jsonResponse.getString("Nombre");

                                                         //iremos al contenido del restaurante seleccionado
                                                         Intent intent = new Intent(Seleccion.this, Moro.class);

                                                         //nos llevaremos los comentarios , el id del usuario, el id del restaurante, la descripcion y nombre del restaurante
                                                         intent.putStringArrayListExtra("comentarios",  new ArrayList<String>());
                                                         if (jsonResponse.getBoolean("comentario")){
                                                             if (jsonResponse.getBoolean("comentario") ==true){
                                                                 ArrayList<String> comentarios = new ArrayList<>();
                                                                 JSONArray jArray = (JSONArray) jsonResponse.get("comentarios");
                                                                 if (jArray != null) {
                                                                     for (int i=0;i<jArray.length();i++){
                                                                         comentarios.add(jArray.getString(i));
                                                                     }
                                                                 }
                                                                 intent.putStringArrayListExtra("comentarios",  comentarios);
                                                             }
                                                         }
                                                         intent.putExtra("user_id", user_id);
                                                         intent.putExtra("restaurant",restaurante_id );
                                                         intent.putExtra("Descripcion",Descripcion);
                                                         intent.putExtra("Nombre",Nombre);
                                                         Seleccion.this.startActivity(intent);
                                                     }


                                                 } catch (JSONException e) {
                                                     e.printStackTrace();
                                                 }
                                             }
                                         };
                                         Restaurantes restaurantes = new Restaurantes(Nombre,responseListener);
                                         RequestQueue queue = Volley.newRequestQueue(Seleccion.this);
                                         queue.add(restaurantes);
                                     }


                                 }
        );





        //---------------------------------------------------------------------------------------------------------


    }




    //--------------------------------menu superior--------------------------------------------

   //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }


    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
           finish();
            System.exit(0);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }





}
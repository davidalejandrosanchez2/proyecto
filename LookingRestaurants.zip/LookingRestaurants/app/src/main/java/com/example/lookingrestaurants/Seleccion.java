package com.example.lookingrestaurants;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;


public class Seleccion extends AppCompatActivity {
ImageButton taco,bongo,oishii,kfc,nando;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion);

         //para los botones
        taco=findViewById(R.id.butonCuchara);
        bongo=findViewById(R.id.butonbongo);
        oishii=findViewById(R.id.butonoishii);
        kfc=findViewById(R.id.butonkfc);
        nando=findViewById(R.id.butonnando);
        Intent intent = getIntent();
        final int user_id = intent.getIntExtra("user_id",1 );


        // cada boton nos mandara al contenido de cada uno de los restaurantes
        taco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Seleccion.this, Cuchara.class);
                intent.putExtra("user_id", user_id);
                Seleccion.this.startActivity(intent);
            }
        });


        bongo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Seleccion.this,ELBONGO.class);
                Seleccion.this.startActivity(intent2);
            }
        });

        nando.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(Seleccion.this, Moro.class);
                Seleccion.this.startActivity(intent3);
            }
        });


        kfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent4 = new Intent(Seleccion.this,vilabrasil.class);
                Seleccion.this.startActivity(intent4);
            }
        });

        oishii.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent5 = new Intent(Seleccion.this,OISHII.class);
                Seleccion.this.startActivity(intent5);
            }
        });






    }


    //--------------------------------menu superior--------------------------------------------

   //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }


    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
           finish();
            System.exit(0);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }





}
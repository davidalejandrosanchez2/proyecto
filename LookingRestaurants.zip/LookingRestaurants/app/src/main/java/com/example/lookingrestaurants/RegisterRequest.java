package com.example.lookingrestaurants;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

// esta clase estara vinculada a la clase Registro y a la bd de xampp
public class RegisterRequest extends StringRequest {
    //hacemos una conexion desde la ip del ordenador junto con el fichero Register.php
    private static final String REGISTER_REQUEST_URL="http://192.168.1.84:8081/Register.php";
    private Map<String,String> params;

    //cada parametro puesto en la clase Registro se ira introduciendo  a los campos de la tabla de la bd de xampp que correspondan
    public RegisterRequest(String Nombre, String Correo, String Usuario, String Clave, Response.Listener<String> listener){
    super(Method.POST, REGISTER_REQUEST_URL,listener,null);
    params=new HashMap<>();
    params.put("Nombre",Nombre);
    params.put("Correo",Correo);
    params.put("Usuario",Usuario);
    params.put("Clave",Clave);

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

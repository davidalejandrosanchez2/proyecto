package com.example.lookingrestaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class Moro extends AppCompatActivity {
    Button localimoro ,volvermoro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moro);
        localimoro= findViewById(R.id.localimoro);
        volvermoro=findViewById(R.id.volvermoro);

        // esta funcion del boton  nos mandara al maps para enseñar las localizaciones
        localimoro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Uri webpage = Uri.parse("https://www.google.es/maps/place/Restaurante+Al+Mounia+-+Alta+cocina+marroqu%C3%AD+en+Madrid/@40.1924871,-3.7251428,9z/data=!4m5!3m4!1s0xd42289af4a1913d:0xa2d704ac1b730ee2!8m2!3d40.4221713!4d-3.6905759?hl=es&authuser=0");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(intent);
            }
        });


// esta funcion del boton  nos mandara  a la seleccion de restaurantes
        volvermoro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent2 = new Intent(Moro.this,Seleccion.class);
                Moro.this.startActivity(intent2);

            }
        });








    }



    //--------------------------------menu superior--------------------------------------------

    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }



    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(Moro.this,MainActivity.class);
            Moro.this.startActivity(intent);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }





}
package com.example.lookingrestaurants;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;
// esta clase estara vinculada a la clase Seleccion,Cuchara,ELBONGO, Moro,OISHII,vilabrasil  y a la bd de xampp
public class Restaurantes extends StringRequest {

    //hacemos una conexion desde la ip del ordenador junto con el fichero Restaurantesid.php
    private static final String RESTAU_REQUEST_URL="http://192.168.1.84:8081/Restaurantesid.php";
    private Map<String,String> params;

    //Después vinculamos  el nombre del restaurante seleccionado con la base de datos para la obtener los datos devueltos
    public Restaurantes(String Nombre, Response.Listener<String> listener){
        super(Method.POST, RESTAU_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("Nombre",Nombre);

    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

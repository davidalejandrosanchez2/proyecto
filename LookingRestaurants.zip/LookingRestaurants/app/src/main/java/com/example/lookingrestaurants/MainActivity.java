package com.example.lookingrestaurants;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    Button iniciar,registrar;
   EditText usuario , clave;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       //para los editText:
        usuario=findViewById(R.id.Usuario);
        clave=findViewById(R.id.Clave);

        //para los botones:
        iniciar=findViewById(R.id.botonIniciar);
        registrar=findViewById(R.id.botonRegistrar);

         // accion que hara el boton de iniciar
        iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String Usuario = usuario.getText().toString();
                final String Clave = clave.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if(success){
                                Intent intent = new Intent(MainActivity.this,Seleccion.class);


                                MainActivity.this.startActivity(intent);

                            }else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setMessage("ingrese bien los datos o registrase")
                                        .setNegativeButton("Cerrar",null)
                                        .create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

               LoginRequest loginRequest = new LoginRequest(Usuario,Clave,responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(loginRequest);

            }
        });

      /* el bot�n iniciar har� una comprobaci�n en la base de datos  del usuario y clave introducidos mediante el LoginRequest y con el fichero Login.php ,
      si uno de esos dos campos es err�neo mandara un mensaje de aviso
       */

    //---------------------------------------------------------------------------------------------------

        // acci�n que har� el boton de registar

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentResgistro =  new Intent(MainActivity.this,Registro.class);
                MainActivity.this.startActivity(intentResgistro);
            }
        });


     // el bot�n registar nos mandara a una pantalla de registro para introducir los datos y estar registrados




    }
}

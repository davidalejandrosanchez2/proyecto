package com.example.lookingrestaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class vilabrasil extends AppCompatActivity {
    TextView descripcion,nombre;
    EditText comentario1;
    Button loc4 ,volver4,enviar4,ver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vilabrasil);

        //para los Texview:
        descripcion=findViewById(R.id.des4);
        nombre=findViewById(R.id.vii);
        //el editText:
        comentario1=findViewById(R.id.comenta4);
        //para los button:
        loc4= findViewById(R.id.locali4);
        volver4=findViewById(R.id.volver4);
        enviar4=findViewById(R.id.EnviarVi);
        ver=findViewById(R.id.vercomentarios4);


        Intent intent = getIntent();
        Intent intent1 = getIntent();
        Intent intent2 = getIntent();
        Intent intent3 = getIntent();


        //recogemos la descripcion del restaurante
        String descripci = intent2.getStringExtra("Descripcion");
        descripcion.setText(descripci);
        //recogemos el nombre del restaurante
        String nombres = intent3.getStringExtra("Nombre");
        nombre.setText(nombres);

        //recogemos el id del usuario
        final int user_id = intent.getIntExtra("user_id",1 );
        //recogemos el id del restaurant
        final int restaurante_id = intent1.getIntExtra("restaurant",2);

        //para el boton enviar
        enviar4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //cogeremos el comentario introducido en el editext
                final String comentario = comentario1.getText().toString();

                Response.Listener<String> resStringListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            //si el envio del comentario se cumplio se enviara un mensaje
                            if (success){

                                Toast.makeText(vilabrasil.this,"comentario enviado", Toast.LENGTH_SHORT).show();
                            }
                            //si falla mandara un mensaje
                            else{   Toast.makeText(vilabrasil.this,"Fallo", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                //vincularemos los datos  user_id,restaurante_id,comentario con la clase  CucharaComentarios para mandarlo a la tabla comentarios de la base de  datos
                CucharaComentarios cucharaComentarios = new CucharaComentarios(user_id,restaurante_id,comentario,resStringListener);
                RequestQueue queue = Volley.newRequestQueue(vilabrasil.this);
                queue.add(cucharaComentarios);
            }
        });


//-----------------------------------------------------------------------------------------------------------------------------

        //para el boton enviar  recogemos el nombre y  los comentarios de la base de datos del restaurante para mandarlo a la clase comentarios mediante la vinculacion de la clase Restaurantes
        ver.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View v) {
                                       Intent intent3 = getIntent();
                                       final String Nombre = intent3.getStringExtra("Nombre");

                                       Response.Listener<String> responseListener = new Response.Listener<String>() {
                                           @Override
                                           public void onResponse(String response) {
                                               try {
                                                   JSONObject jsonResponse = new JSONObject(response);
                                                   boolean success = jsonResponse.getBoolean("success");
                                                   if (success){
                                                       //recogemos de la base de datos el  nombre del restaurante mediante la clase Restaurantes :
                                                       final String Nombre = jsonResponse.getString("Nombre");

                                                       //iremos al contenido del restaurante seleccionado
                                                       Intent intent = new Intent(vilabrasil.this, Comentarios.class);

                                                       //nos llevaremos los comentarios y el  nombre del restaurante
                                                       intent.putStringArrayListExtra("comentarios",  new ArrayList<String>());
                                                       if (jsonResponse.getBoolean("comentario")){
                                                           if (jsonResponse.getBoolean("comentario") ==true){
                                                               ArrayList<String> comentarios = new ArrayList<>();
                                                               JSONArray jArray = (JSONArray) jsonResponse.get("comentarios");
                                                               if (jArray != null) {
                                                                   for (int i=0;i<jArray.length();i++){
                                                                       comentarios.add(jArray.getString(i));
                                                                   }
                                                               }
                                                               intent.putStringArrayListExtra("comentarios",  comentarios);
                                                           }
                                                       }
                                                       intent.putExtra("Nombre",Nombre);
                                                       vilabrasil.this.startActivity(intent);
                                                   }


                                               } catch (JSONException e) {
                                                   e.printStackTrace();
                                               }
                                           }
                                       };
                                       Restaurantes restaurantes = new Restaurantes(Nombre,responseListener);
                                       RequestQueue queue = Volley.newRequestQueue(vilabrasil.this);
                                       queue.add(restaurantes);
                                   }


                               }
        );

        //--------------------------------------------------------------------------------------------


        // esta funcion del boton  nos mandara al maps para enseñar las localizaciones
        loc4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Uri webpage = Uri.parse("https://www.google.es/maps/search/vila+brasil/@40.3659685,-3.6863362,11.71z?hl=es&authuser=0");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(intent);
            }
        });


// esta funcion del boton  nos mandara  a la seleccion de restaurantes
        volver4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                finish();

            }
        });

    }

    //--------------------------------menu superior--------------------------------------------

    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }

    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(vilabrasil.this,MainActivity.class);
            vilabrasil.this.startActivity(intent);
            return  true;
        }

        return super.onOptionsItemSelected(item);
    }
}
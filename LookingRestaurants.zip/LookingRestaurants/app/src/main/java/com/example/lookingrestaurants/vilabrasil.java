package com.example.lookingrestaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class vilabrasil extends AppCompatActivity {
    Button localivilabrasil ,volvervilabrasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vilabrasil);


        localivilabrasil= findViewById(R.id.localivilabrasil);
        volvervilabrasil=findViewById(R.id.volvervilabrasil);

        // esta funcion del boton  nos mandara al maps para enseñar las localizaciones
        localivilabrasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Uri webpage = Uri.parse("https://www.google.es/maps/search/vila+brasil/@40.3659685,-3.6863362,11.71z?hl=es&authuser=0");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(intent);
            }
        });


// esta funcion del boton  nos mandara  a la seleccion de restaurantes
        volvervilabrasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent2 = new Intent(vilabrasil.this,Seleccion.class);
                vilabrasil.this.startActivity(intent2);

            }
        });








    }



    //--------------------------------menu superior--------------------------------------------

    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }



    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(vilabrasil.this,MainActivity.class);
            vilabrasil.this.startActivity(intent);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }





}
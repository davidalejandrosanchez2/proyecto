package com.example.lookingrestaurants;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Cuchara extends AppCompatActivity {
  EditText comentarios;
    Button localicuchara ,volvercuchara,enviar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuchara);

        localicuchara= findViewById(R.id.localicuchara);
        volvercuchara=findViewById(R.id.volvercuchara);
        comentarios=findViewById(R.id.comenta);
        enviar=findViewById(R.id.EnviarCuchara);
        Intent intent = getIntent();
        final int user_id = intent.getIntExtra("user_id",1 );


        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String comentario = comentarios.getText().toString();

                Response.Listener<String> resStringListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if (success){

                                Toast.makeText(Cuchara.this,"comentario enviado", Toast.LENGTH_SHORT).show();
                            }
                            else{   Toast.makeText(Cuchara.this,"Fallo", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                CucharaComentarios cucharaComentarios = new CucharaComentarios(user_id,comentario,resStringListener);
                RequestQueue queue = Volley.newRequestQueue(Cuchara.this);
                queue.add(cucharaComentarios);
            }
        });



        // esta funcion del boton  nos mandara al maps para enseñar las localizaciones
        localicuchara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri webpage = Uri.parse("https://www.google.es/maps/place/La+Cuchara/@40.4318461,-3.6784824,16.04z/data=!4m8!1m2!2m1!1sla+cuchara+restaurante!3m4!1s0xd4228b88a8f2a4d:0xa8b6fd2cac8b8d84!8m2!3d40.4329564!4d-3.674843?hl=es&authuser=0");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(intent);
            }
        });


// esta funcion del boton  nos mandara  a la seleccion de restaurantes
        volvercuchara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Cuchara.this,Seleccion.class);
                Cuchara.this.startActivity(intent2);

            }
        });
    }






    //--------------------------------menu superior--------------------------------------------

    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }



    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(Cuchara.this,MainActivity.class);
            Cuchara.this.startActivity(intent);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }



}
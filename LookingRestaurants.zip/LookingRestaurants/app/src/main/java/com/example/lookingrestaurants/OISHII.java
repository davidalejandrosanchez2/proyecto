package com.example.lookingrestaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class OISHII extends AppCompatActivity {
Button loc6, volver3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_i_s_h_i_i);

        loc6=findViewById(R.id.locali6);
        volver3=findViewById(R.id.volver3);


        // esta funcion del boton  nos mandara al maps para enseñar las localizaciones

        loc6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri webpage = Uri.parse("https://www.google.com/maps/search/oishii+ramen/@44.627171,-7.9450381,4.76z");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(intent);
            }
        });



// esta funcion del boton  nos mandara  a la seleccion de restaurantes

        volver3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent2 = new Intent(OISHII.this,Seleccion.class);
                OISHII.this.startActivity(intent2);

            }
        });









    }

    //--------------------------------menu superior--------------------------------------------


    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }



    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(OISHII.this,MainActivity.class);
            OISHII.this.startActivity(intent);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }





}
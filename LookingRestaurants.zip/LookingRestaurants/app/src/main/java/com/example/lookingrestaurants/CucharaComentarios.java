package com.example.lookingrestaurants;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;
// esta clase estara vinculada a la clase Cuchara,ELBONGO, Moro,OISHII,vilabrasil  y a la bd de xampp
public class CucharaComentarios extends StringRequest {
    //hacemos una conexion desde la ip del ordenador junto con el fichero cometarioscu.php
    private static final String Comentarios_REQUEST_URL="http://192.168.1.84:8081/cometarioscu.php";
    private Map<String,String>params;
    //cada parametro obtenido  en las  clases Cuchara,ELBONGO, Moro,OISHII,vilabrasil   se ira introduciendo  a los campos de la tabla  comentarios de la  bd de xampp que correspondan
    public CucharaComentarios(int user_id,int restaurante_id ,String comentario, Response.Listener<String> listener) {
        super(Method.POST,Comentarios_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("user_id", Integer.toString(user_id));
        params.put("restaurante_id", Integer.toString(restaurante_id));
        params.put("comentario",comentario);

    }


    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

package com.example.lookingrestaurants;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class CucharaComentarios extends StringRequest {

    private static final String Comentarios_REQUEST_URL="http://192.168.1.84:8081/cometarioscu.php";
    private Map<String,String>params;
    public CucharaComentarios(int user_id,String comentario, Response.Listener<String> listener) {
        super(Method.POST,Comentarios_REQUEST_URL,listener,null);
        params=new HashMap<>();
        params.put("user_id", Integer.toString(user_id));
        params.put("comentario",comentario);

    }


    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

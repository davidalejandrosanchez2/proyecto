package com.example.lookingrestaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;

public class Comentarios extends AppCompatActivity {
    TextView nombre;
    LinearLayout my_layout;
    Button volver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comentarios);
        nombre=findViewById(R.id.nombretotal);
        my_layout=findViewById(R.id.my_layout);
        volver=findViewById(R.id.volverr);
        Intent intent = getIntent();
        Intent intent1 = getIntent();

        //recogemos el nombre y comentarios del restaurante
        String nombres = intent.getStringExtra("Nombre");
        ArrayList<String> comentarios = (intent1.getStringArrayListExtra("comentarios").isEmpty()) ? new ArrayList<String>() : intent1.getStringArrayListExtra("comentarios");


        //creamos dentro del LinearLayout texview de manera automatica cada vez que reciba comentarios
        LinearLayout myLayout = (LinearLayout) findViewById(R.id.my_layout);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams( LinearLayout.LayoutParams.WRAP_CONTENT,    LinearLayout.LayoutParams.WRAP_CONTENT);
        if (!comentarios.isEmpty()){

            TextView[] pairs=new TextView[comentarios.size()];
            for(int l=0; l<comentarios.size(); l++)
            {
                pairs[l] = new TextView(this);
                pairs[l].setTextSize(15);
                pairs[l].setLayoutParams(lp);
                pairs[l].setId(l);
                pairs[l].setText( comentarios.get(l).substring(2,comentarios.get(l).length()-2) );
                myLayout.addView(pairs[l]);
            }
        }
        nombre.setText(nombres);
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });




    }


    //--------------------------------menu superior--------------------------------------------

    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }

    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(this,MainActivity.class);
            Comentarios.this.startActivity(intent);
            return  true;
        }

        return super.onOptionsItemSelected(item);
    }

}


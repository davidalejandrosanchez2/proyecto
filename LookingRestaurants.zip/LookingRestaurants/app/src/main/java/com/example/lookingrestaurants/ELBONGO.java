package com.example.lookingrestaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class ELBONGO extends AppCompatActivity {
    Button loc ,volver2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_e_l_b_o_n_g_o);

        loc= findViewById(R.id.locali2);
        volver2=findViewById(R.id.volver2);

        // esta funcion del boton  nos mandara al maps para enseñar las localizaciones
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Uri webpage = Uri.parse("https://www.google.es/maps/place/Bar-Restaurante+Bongo+Nancy/@40.3448577,-3.7104406,18z/data=!4m5!3m4!1s0xd422724392812c3:0xb06f13058795d64!8m2!3d40.3448364!4d-3.7089422?hl=es&authuser=0");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(intent);
            }
        });


// esta funcion del boton  nos mandara  a la seleccion de restaurantes
        volver2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent2 = new Intent(ELBONGO.this,Seleccion.class);
                ELBONGO.this.startActivity(intent2);

            }
        });








    }



    //--------------------------------menu superior--------------------------------------------

    //menu superior para salir a la pantalla principal de la app
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menusuperior,menu);

        return  true;
    }



    public  boolean onOptionsItemSelected(MenuItem item){

        int id=item.getItemId();

        if (id==R.id.item1){
            Intent intent = new Intent(ELBONGO.this,MainActivity.class);
            ELBONGO.this.startActivity(intent);
            return  true;
        }




        return super.onOptionsItemSelected(item);
    }





}